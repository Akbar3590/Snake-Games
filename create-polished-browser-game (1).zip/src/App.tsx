import { useCallback, useEffect, useRef, useState } from "react";
import { Engine, type DirName, type GameResult, type GameState } from "./game/engine";
import { audio } from "./game/audio";
import {
  addScore,
  loadName,
  loadScores,
  renameScore,
  saveName,
  type ScoreEntry,
} from "./game/highscores";
import { GameOverScreen, PauseScreen, StartScreen, TouchPad } from "./ui/Screens";

function PowerBar({ id, label, color }: { id: string; label: string; color: string }) {
  return (
    <div
      id={id}
      className="pointer-events-none transition-all duration-300 opacity-0 translate-y-2.5"
    >
      <div className="flex items-center gap-1.5">
        <span className="w-1.5 h-1.5 rounded-full" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
        <span className="text-[9px] font-display font-bold tracking-widest" style={{ color }}>
          {label}
        </span>
      </div>
      <div className="w-20 h-1 mt-0.5 rounded-full bg-white/10 overflow-hidden">
        <div
          id={`${id}-bar`}
          className="h-full w-full rounded-full origin-left"
          style={{ background: color, transform: "scaleX(0)", boxShadow: `0 0 8px ${color}` }}
        />
      </div>
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<Engine | null>(null);
  const [state, setState] = useState<GameState>("menu");
  const [result, setResult] = useState<GameResult | null>(null);
  const [entryId, setEntryId] = useState<string | null>(null);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [name, setName] = useState(() => loadName());
  const [muted, setMuted] = useState(audio.muted);
  const [isTouch] = useState(
    () => window.matchMedia?.("(pointer: coarse)").matches ?? false
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new Engine(canvas, {
      onState: (s) => setState(s),
      onGameOver: (r) => {
        if (r.qualified) {
          const res = addScore({
            name: loadName(),
            score: r.score,
            apples: r.apples,
            maxCombo: r.maxCombo,
          });
          setScores(res.list);
          setEntryId(res.rank > 0 ? res.id : null);
        } else {
          setEntryId(null);
        }
        setResult(r);
      },
      onMuteChange: (m) => setMuted(m),
    });
    engineRef.current = engine;
    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  const start = useCallback(() => {
    audio.unlock();
    audio.click();
    engineRef.current?.startGame();
  }, []);

  const resume = useCallback(() => {
    audio.click();
    engineRef.current?.resume();
  }, []);

  const restart = useCallback(() => {
    audio.unlock();
    audio.click();
    engineRef.current?.startGame();
  }, []);

  const toMenu = useCallback(() => {
    audio.click();
    engineRef.current?.goMenu();
  }, []);

  const handleDir = useCallback((d: DirName) => {
    engineRef.current?.queueDir(d);
  }, []);

  const toggleMute = useCallback(() => {
    audio.unlock();
    audio.setMuted(!audio.muted);
    setMuted(audio.muted);
  }, []);

  const handleName = useCallback(
    (v: string) => {
      const n = v
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, "")
        .slice(0, 3);
      setName(n);
      saveName(n);
      if (entryId) setScores(renameScore(entryId, n || "???"));
    },
    [entryId]
  );

  const inGame = state === "playing" || state === "countdown" || state === "dying";

  return (
    <div className="app-h w-full flex flex-col bg-void overflow-hidden font-body">
      <main className="relative flex-1 min-h-0">
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" />
        <div className="scanlines absolute inset-0 z-20" />
        <div className="vignette absolute inset-0 z-20" />

        {/* ---------- HUD ---------- */}
        <div
          className={`absolute inset-x-0 top-0 z-30 flex items-start justify-between p-3 sm:p-4 transition-opacity duration-300 ${
            inGame ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
        >
          <div className="pointer-events-none">
            <p className="text-[9px] tracking-[0.4em] text-cyan-300/70 font-semibold">SCORE</p>
            <p
              id="hud-score"
              className="font-display text-3xl sm:text-4xl font-black text-cyan-100 leading-none tabular-nums drop-shadow-[0_0_12px_rgba(34,211,238,0.7)]"
            >
              0
            </p>
            {/* combo pill */}
            <div id="hud-combo" className="mt-2 transition-all duration-200 opacity-0" style={{ transform: "translateY(-8px) scale(0.9)" }}>
              <div className="inline-flex flex-col items-stretch rounded-lg bg-fuchsia-500/15 border border-fuchsia-400/50 px-3 py-1.5 shadow-[0_0_16px_rgba(232,121,249,0.35)]">
                <span className="flex items-center gap-1.5">
                  <span className="text-[9px] tracking-[0.3em] text-fuchsia-200 font-bold">COMBO</span>
                  <span id="hud-combo-num" className="font-display text-base font-black text-fuchsia-200 leading-none">
                    ×2
                  </span>
                </span>
                <div className="h-1 mt-1 rounded-full bg-fuchsia-900/60 overflow-hidden">
                  <div
                    id="hud-combo-bar"
                    className="h-full w-full rounded-full origin-left bg-gradient-to-r from-fuchsia-400 to-pink-300"
                    style={{ transform: "scaleX(1)" }}
                  />
                </div>
              </div>
            </div>
            {/* power bars */}
            <div className="flex gap-3 mt-2.5">
              <PowerBar id="hud-pow-slow" label="SLOW" color="#67e8f9" />
              <PowerBar id="hud-pow-ghost" label="GHOST" color="#e6ebff" />
              <PowerBar id="hud-pow-x2" label="×2" color="#fbbf24" />
            </div>
          </div>

          <div className="flex flex-col items-end gap-1.5">
            <div className="pointer-events-none text-right">
              <p className="text-[9px] tracking-[0.4em] text-amber-300/70 font-semibold">BEST</p>
              <p
                id="hud-best"
                className="font-display text-xl sm:text-2xl font-bold text-amber-200/90 leading-none tabular-nums"
              >
                0
              </p>
            </div>
            <div className="flex gap-1.5 pointer-events-auto">
              <button
                className="icon-btn"
                onClick={() => engineRef.current?.togglePause()}
                aria-label="Pause"
              >
                {state === "paused" ? (
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                ) : (
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M6 4h4v16H6zM14 4h4v16h-4z" />
                  </svg>
                )}
              </button>
              <button className="icon-btn" onClick={toggleMute} aria-label="Mute">
                {muted ? (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M3 9v6h4l5 5V4L7 9H3zm13.6 3l2.7-2.7-1.4-1.4-2.7 2.7-2.7-2.7-1.4 1.4 2.7 2.7-2.7 2.7 1.4 1.4 2.7-2.7 2.7 2.7 1.4-1.4-2.7-2.7z" />
                  </svg>
                ) : (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.5 4.5 0 0 0 2.5-4zM14 3.2v2.1a7 7 0 0 1 0 13.4v2.1a9 9 0 0 0 0-17.6z" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* ---------- overlays ---------- */}
        {state === "menu" && (
          <StartScreen scores={scores} best={scores[0]?.score ?? 0} isTouch={isTouch} onStart={start} />
        )}
        {state === "paused" && (
          <PauseScreen onResume={resume} onRestart={restart} onMenu={toMenu} />
        )}
        {state === "gameover" && result && (
          <GameOverScreen
            result={result}
            entryId={entryId}
            scores={scores}
            name={name}
            onNameChange={handleName}
            onRestart={restart}
            onMenu={toMenu}
            isTouch={isTouch}
          />
        )}
      </main>

      {isTouch && <TouchPad onDir={handleDir} />}

      <footer className="shrink-0 text-center pb-2 pt-1 text-[9px] sm:text-[10px] tracking-[0.35em] text-slate-500 select-none">
        {isTouch
          ? "SWIPE THE BOARD TO STEER"
          : "←↑↓→ / WASD STEER · SPACE START · P PAUSE · M MUTE"}
      </footer>
    </div>
  );
}
