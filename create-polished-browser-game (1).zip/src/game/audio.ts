/* Tiny procedural WebAudio synth: SFX + looping bass/kick, no assets. */

const MUTE_KEY = "ns_muted";

class AudioSys {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private musicTimer: number | null = null;
  private nextNoteTime = 0;
  private step = 0;
  private playing = false;
  muted = false;

  constructor() {
    try {
      this.muted = localStorage.getItem(MUTE_KEY) === "1";
    } catch {
      this.muted = false;
    }
  }

  /** Must be called from a user gesture at least once. */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      this.master.connect(this.ctx.destination);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.5;
      this.musicGain.connect(this.master);
      // white noise buffer for percussion
      const len = Math.floor(this.ctx.sampleRate * 0.35);
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    try {
      localStorage.setItem(MUTE_KEY, m ? "1" : "0");
    } catch {
      /* ignore */
    }
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.02);
    }
  }

  private env(freq: number, dur: number, type: OscillatorType, vol: number, slideTo?: number) {
    if (!this.ctx || !this.master || this.muted) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(dur: number, vol: number, filterFreq: number) {
    if (!this.ctx || !this.master || !this.noiseBuf || this.muted) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = filterFreq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t);
    src.stop(t + dur + 0.02);
  }

  eat(combo: number) {
    const base = 300 + Math.min(9, combo) * 42;
    this.env(base, 0.09, "square", 0.16, base * 1.6);
    this.env(base * 2, 0.09, "sine", 0.1, base * 2.4);
  }

  power() {
    [523, 659, 784, 1046].forEach((f, i) => {
      setTimeout(() => this.env(f, 0.12, "triangle", 0.16), i * 55);
    });
  }

  gold() {
    [660, 880, 1320, 1760].forEach((f, i) => {
      setTimeout(() => this.env(f, 0.16, "square", 0.12), i * 70);
    });
    this.noise(0.25, 0.06, 6000);
  }

  death() {
    this.env(260, 0.7, "sawtooth", 0.22, 32);
    this.noise(0.5, 0.22, 900);
    this.env(130, 0.5, "square", 0.14, 30);
  }

  click() {
    this.env(700, 0.05, "square", 0.1, 900);
  }

  start() {
    this.env(180, 0.35, "sawtooth", 0.15, 720);
    this.env(360, 0.35, "square", 0.08, 1440);
  }

  count(n: number) {
    this.env(n === 0 ? 880 : 440, 0.09, "square", 0.14);
  }

  best() {
    this.env(880, 0.12, "triangle", 0.15);
    setTimeout(() => this.env(1174, 0.14, "triangle", 0.15), 90);
    setTimeout(() => this.env(1568, 0.22, "triangle", 0.15), 180);
  }

  /* ------- music: 8-step synthwave loop ------- */
  startMusic() {
    if (this.playing || !this.ctx) return;
    this.playing = true;
    this.step = 0;
    this.nextNoteTime = this.ctx.currentTime + 0.1;
    this.musicTimer = window.setInterval(() => this.schedule(), 80);
  }

  stopMusic() {
    this.playing = false;
    if (this.musicTimer !== null) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  private schedule() {
    if (!this.ctx || !this.musicGain || this.muted || !this.playing) return;
    const stepDur = 60 / 138 / 2; // 138 bpm, 8th notes
    const bass = [55, 55, 65.41, 55, 49, 49, 73.42, 55];
    const arp = [220, 261.63, 329.63, 261.63, 196, 246.94, 293.66, 246.94];
    while (this.nextNoteTime < this.ctx.currentTime + 0.25) {
      const s = this.step % 8;
      const t = this.nextNoteTime;
      // kick on every step
      const ko = this.ctx.createOscillator();
      const kg = this.ctx.createGain();
      ko.type = "sine";
      ko.frequency.setValueAtTime(120, t);
      ko.frequency.exponentialRampToValueAtTime(38, t + 0.1);
      kg.gain.setValueAtTime(0.5, t);
      kg.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
      ko.connect(kg).connect(this.musicGain);
      ko.start(t);
      ko.stop(t + 0.14);
      // bass note
      const bo = this.ctx.createOscillator();
      const bg = this.ctx.createGain();
      bo.type = "sawtooth";
      bo.frequency.value = bass[s];
      bg.gain.setValueAtTime(0.16, t);
      bg.gain.exponentialRampToValueAtTime(0.001, t + stepDur * 0.92);
      const lp = this.ctx.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.value = 420;
      bo.connect(lp).connect(bg).connect(this.musicGain);
      bo.start(t);
      bo.stop(t + stepDur);
      // sparkle arp on even steps
      if (s % 2 === 0) {
        const ao = this.ctx.createOscillator();
        const ag = this.ctx.createGain();
        ao.type = "triangle";
        ao.frequency.value = arp[s];
        ag.gain.setValueAtTime(0.05, t);
        ag.gain.exponentialRampToValueAtTime(0.001, t + stepDur);
        ao.connect(ag).connect(this.musicGain);
        ao.start(t);
        ao.stop(t + stepDur);
      }
      this.nextNoteTime += stepDur;
      this.step++;
    }
  }
}

export const audio = new AudioSys();
