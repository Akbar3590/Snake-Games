import { audio } from "./audio";
import { qualifies } from "./highscores";

export type GameState = "menu" | "playing" | "countdown" | "paused" | "dying" | "gameover";
export type DirName = "up" | "down" | "left" | "right";
export type PowerKind = "slow" | "ghost" | "x2";

export interface GameResult {
  score: number;
  apples: number;
  maxCombo: number;
  qualified: boolean;
}

export interface EngineCallbacks {
  onState: (s: GameState) => void;
  onGameOver: (r: GameResult) => void;
  onMuteChange: (m: boolean) => void;
}

interface Vec {
  x: number;
  y: number;
}
interface SnakeState {
  cells: Vec[];
  prev: Vec[];
  dir: DirName;
  dirs: DirName[];
  grow: number;
  acc: number;
  chomp: number;
  respawn: number;
}
interface Particle {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  r: number;
  g: number;
  b: number;
  grav: number;
  drag: number;
}
interface Ring {
  x: number;
  y: number;
  maxR: number;
  life: number;
  maxLife: number;
  color: string;
  width: number;
}
interface Popup {
  x: number;
  y: number;
  text: string;
  color: string;
  size: number;
  life: number;
  maxLife: number;
}
interface FieldPower {
  kind: PowerKind;
  x: number;
  y: number;
  age: number;
  life: number;
}
interface GoldenApple {
  x: number;
  y: number;
  age: number;
  life: number;
}

const N = 21;
const COMBO_WINDOW = 4.5;
const DIRS: Record<DirName, Vec> = {
  up: { x: 0, y: -1 },
  down: { x: 0, y: 1 },
  left: { x: -1, y: 0 },
  right: { x: 1, y: 0 },
};
const OPPOSITE: Record<DirName, DirName> = {
  up: "down",
  down: "up",
  left: "right",
  right: "left",
};
const LEFT_OF: Record<DirName, DirName> = { up: "left", left: "down", down: "right", right: "up" };
const RIGHT_OF: Record<DirName, DirName> = { up: "right", right: "down", down: "left", left: "up" };
const POWER_DUR: Record<PowerKind, number> = { slow: 5, ghost: 6, x2: 8 };
const POWER_COLOR: Record<PowerKind, string> = {
  slow: "rgba(103,232,249,",
  ghost: "rgba(230,235,255,",
  x2: "rgba(251,191,36,",
};
const FONT_DISPLAY = '"Orbitron","Chakra Petch",sans-serif';
const FONT_BODY = '"Chakra Petch",sans-serif';

const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const wrap = (v: number) => ((v % N) + N) % N;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
const easeOutBack = (t: number) => {
  const c = 1.70158;
  return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2);
};

/** Precomputed head→tail color palette */
const PALETTE: string[] = [];
for (let i = 0; i < 48; i++) {
  const t = i / 47;
  const r = Math.round(34 + (124 - 34) * t);
  const g = Math.round(211 + (58 - 211) * t);
  const b = Math.round(238 + (237 - 238) * t);
  PALETTE.push(`rgb(${r},${g},${b})`);
}

function makeGlow(r: number, g: number, b: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const x = c.getContext("2d")!;
  const gr = x.createRadialGradient(32, 32, 2, 32, 32, 32);
  gr.addColorStop(0, `rgba(${r},${g},${b},0.85)`);
  gr.addColorStop(0.4, `rgba(${r},${g},${b},0.28)`);
  gr.addColorStop(1, `rgba(${r},${g},${b},0)`);
  x.fillStyle = gr;
  x.fillRect(0, 0, 64, 64);
  return c;
}

export class Engine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cbs: EngineCallbacks;
  private raf = 0;
  private last = 0;
  private time = 0;
  private destroyed = false;

  // layout
  private w = 0;
  private h = 0;
  private dpr = 1;
  private bx = 0;
  private by = 0;
  private board = 0;
  private cell = 1;
  private bgGrad: CanvasGradient | null = null;
  private gridLayer: HTMLCanvasElement | null = null;
  private glowCyan = makeGlow(34, 211, 238);
  private glowPink = makeGlow(244, 114, 182);
  private glowGold = makeGlow(251, 191, 36);
  private glowPurple = makeGlow(167, 139, 250);

  // state
  state: GameState = "menu";
  score = 0;
  private best = 0;
  private apples = 0;
  private combo = 0;
  private comboTimer = 0;
  private maxCombo = 0;
  private bestCelebrated = false;
  private snake: SnakeState = this.freshSnake();
  private demo: SnakeState = this.freshSnake();
  private food: Vec | null = null;
  private foodAge = 0;
  private gold: GoldenApple | null = null;
  private goldAt = 12;
  private fieldPow: FieldPower | null = null;
  private powAt = 8;
  private slow = 0;
  private ghost = 0;
  private x2 = 0;
  private acc = 0;
  private interval = 0.15;
  private deathT = 0;
  private deathEvents: { t: number; x: number; y: number; fired: boolean }[] = [];
  private deathAllFired = false;
  private countT = 0;
  private countNum = -1;

  // juice
  private trauma = 0;
  private flashA = 0;
  private flashColor = "255,255,255";
  private particles: Particle[] = [];
  private rings: Ring[] = [];
  private popups: Popup[] = [];
  private embers: { x: number; y: number; vy: number; phase: number; size: number; gold: boolean }[] = [];

  // input
  private pointerActive = false;
  private pointerId = -1;
  private anchorX = 0;
  private anchorY = 0;

  private hud: Record<string, HTMLElement | null> = {};
  private hudCache: Record<string, string> = {};
  private ro: ResizeObserver | null = null;

  constructor(canvas: HTMLCanvasElement, cbs: EngineCallbacks) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.cbs = cbs;
    this.best = this.loadBest();
    for (let i = 0; i < 512; i++) {
      this.particles.push({
        alive: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, maxLife: 1,
        size: 2, r: 255, g: 255, b: 255, grav: 0, drag: 0,
      });
    }
    for (let i = 0; i < 34; i++) {
      this.embers.push({
        x: Math.random(), y: Math.random(), vy: rnd(0.008, 0.03),
        phase: rnd(0, Math.PI * 2), size: rnd(1.2, 3.4), gold: Math.random() < 0.35,
      });
    }
    this.resetDemo();
    this.resetFood();

    canvas.style.touchAction = "none";
    window.addEventListener("keydown", this.onKey, { passive: false });
    canvas.addEventListener("pointerdown", this.onPointerDown);
    canvas.addEventListener("pointermove", this.onPointerMove);
    canvas.addEventListener("pointerup", this.onPointerUp);
    canvas.addEventListener("pointercancel", this.onPointerUp);
    document.addEventListener("visibilitychange", this.onVisibility);
    window.addEventListener("blur", this.onBlur);

    const parent = canvas.parentElement;
    if (parent) {
      this.ro = new ResizeObserver(() => this.resize());
      this.ro.observe(parent);
    }
    window.addEventListener("resize", this.resize);
    this.resize();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKey);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerup", this.onPointerUp);
    this.canvas.removeEventListener("pointercancel", this.onPointerUp);
    document.removeEventListener("visibilitychange", this.onVisibility);
    window.removeEventListener("blur", this.onBlur);
    window.removeEventListener("resize", this.resize);
    this.ro?.disconnect();
    audio.stopMusic();
  }

  /* ================= public controls ================= */

  startGame() {
    if (this.state !== "menu" && this.state !== "gameover" && this.state !== "paused") return;
    audio.unlock();
    this.resetWorld();
    this.setState("playing");
    audio.start();
    audio.startMusic();
    const c = this.px(N / 2 - 0.5, N / 2 - 0.5);
    this.popup("GO!", c.x, c.y - this.cell * 2.2, "#a5f3fc", Math.round(this.cell * 1.5));
    this.ring(c.x, c.y, this.board * 0.3, "rgba(103,232,249,0.8)", 3);
    this.shake(0.18);
  }

  togglePause() {
    if (this.state === "playing") {
      this.setState("paused");
      audio.stopMusic();
      audio.click();
    } else if (this.state === "paused") {
      this.resume();
    }
  }

  resume() {
    if (this.state !== "paused") return;
    audio.unlock();
    this.setState("countdown");
    this.countT = 0.9;
    this.countNum = -1;
    audio.startMusic();
  }

  goMenu() {
    if (this.state !== "gameover" && this.state !== "paused") return;
    audio.stopMusic();
    this.resetDemo();
    this.resetFood();
    this.setState("menu");
  }

  queueDir(d: DirName) {
    if (this.state !== "playing" && this.state !== "countdown") return;
    const s = this.snake;
    const lastDir = s.dirs.length ? s.dirs[s.dirs.length - 1] : s.dir;
    if (d === lastDir || d === OPPOSITE[lastDir]) return;
    if (s.dirs.length < 3) s.dirs.push(d);
  }

  /* ================= setup / reset ================= */

  private freshSnake(): SnakeState {
    return { cells: [], prev: [], dir: "right", dirs: [], grow: 0, acc: 0, chomp: 0, respawn: 0 };
  }

  private resetWorld() {
    const s = this.snake;
    s.cells = [];
    const startY = (N / 2) | 0;
    for (let i = 0; i < 4; i++) s.cells.push({ x: ((N / 2) | 0) - i, y: startY });
    s.prev = s.cells.map((c) => ({ ...c }));
    s.dir = "right";
    s.dirs = [];
    s.grow = 0;
    s.acc = 0;
    s.chomp = 0;
    this.score = 0;
    this.apples = 0;
    this.combo = 0;
    this.comboTimer = 0;
    this.maxCombo = 0;
    this.bestCelebrated = false;
    this.slow = 0;
    this.ghost = 0;
    this.x2 = 0;
    this.acc = 0;
    this.interval = 0.15;
    this.gold = null;
    this.fieldPow = null;
    this.goldAt = this.time + rnd(11, 17);
    this.powAt = this.time + rnd(6.5, 9.5);
    this.trauma = 0;
    this.flashA = 0;
    this.particles.forEach((p) => (p.alive = false));
    this.rings.length = 0;
    this.popups.length = 0;
    // first apple straight ahead: instant reward
    this.food = { x: wrap(((N / 2) | 0) + 6), y: startY };
    this.foodAge = 0;
  }

  private resetDemo() {
    const d = this.demo;
    d.cells = [];
    for (let i = 0; i < 7; i++) d.cells.push({ x: wrap(3 - i), y: (N / 2) | 0 });
    d.prev = d.cells.map((c) => ({ ...c }));
    d.dir = "right";
    d.dirs = [];
    d.grow = 0;
    d.acc = 0;
    d.respawn = 0;
  }

  private resetFood() {
    this.food = this.emptyCell(4);
    this.foodAge = 0;
  }

  private emptyCell(minHeadDist: number): Vec {
    for (let tries = 0; tries < 400; tries++) {
      const x = (Math.random() * N) | 0;
      const y = (Math.random() * N) | 0;
      if (this.food && x === this.food.x && y === this.food.y) continue;
      if (this.gold && x === this.gold.x && y === this.gold.y) continue;
      if (this.fieldPow && x === this.fieldPow.x && y === this.fieldPow.y) continue;
      const occupied = (list: Vec[]) => list.some((c) => c.x === x && c.y === y);
      const near = (list: Vec[]) =>
        list.some((c) => Math.abs(c.x - x) <= minHeadDist && Math.abs(c.y - y) <= minHeadDist);
      if (occupied(this.snake.cells)) continue;
      if (this.state === "menu" && occupied(this.demo.cells)) continue;
      if (near(this.snake.cells)) continue;
      return { x, y };
    }
    return { x: 0, y: 0 };
  }

  private setState(s: GameState) {
    this.state = s;
    this.cbs.onState(s);
  }

  /* ================= loop ================= */

  private frame = (ts: number) => {
    if (this.destroyed) return;
    this.raf = requestAnimationFrame(this.frame);
    const dt = clamp((ts - this.last) / 1000, 0, 0.05);
    this.last = ts;
    this.time += dt;

    this.updateEmbers(dt);

    if (this.state === "playing") {
      this.updatePlaying(dt);
    } else if (this.state === "countdown") {
      this.countT -= dt;
      const n = Math.ceil(this.countT / 0.3);
      if (n !== this.countNum && n >= 0 && n <= 3) {
        this.countNum = n;
        audio.count(n);
      }
      if (this.countT <= 0) {
        this.setState("playing");
        audio.count(0);
      }
    } else if (this.state === "dying") {
      this.updateDying(dt);
    } else if (this.state === "menu") {
      this.updateDemo(dt);
    }

    const simScale =
      this.state === "dying" ? 0.55 : this.state === "playing" && this.slow > 0 ? 0.55 : 1;
    this.updateFx(dt * simScale);

    if (this.state === "playing" || this.state === "countdown") {
      this.slow = Math.max(0, this.slow - dt);
      this.ghost = Math.max(0, this.ghost - dt);
      this.x2 = Math.max(0, this.x2 - dt);
      if (this.combo > 0) {
        this.comboTimer -= dt;
        if (this.comboTimer <= 0) this.combo = 0;
      }
      if (this.fieldPow) {
        this.fieldPow.age += dt;
        if (this.fieldPow.age > this.fieldPow.life) this.fieldPow = null;
      }
      if (this.gold) {
        this.gold.age += dt;
        if (this.gold.age > this.gold.life) this.gold = null;
      }
      if (!this.fieldPow && this.time > this.powAt) {
        const kind: PowerKind = (["slow", "ghost", "x2"] as PowerKind[])[(Math.random() * 3) | 0];
        const c = this.emptyCell(3);
        this.fieldPow = { kind, x: c.x, y: c.y, age: 0, life: 8 };
        this.powAt = this.time + rnd(6.5, 10.5);
      }
      if (!this.gold && this.time > this.goldAt) {
        const c = this.emptyCell(3);
        this.gold = { x: c.x, y: c.y, age: 0, life: 9 };
        this.goldAt = this.time + rnd(14, 22);
      }
    }

    this.trauma = Math.max(0, this.trauma - dt * 1.7);
    this.flashA = Math.max(0, this.flashA - dt * 3.4);
    this.writeHud();
    this.render();
  };

  private updatePlaying(dt: number) {
    const s = this.snake;
    this.interval = Math.max(0.068, 0.15 - this.apples * 0.0022);
    const scale = this.slow > 0 ? 0.55 : 1;
    this.acc += dt * scale;
    let guard = 0;
    while (this.acc >= this.interval && this.state === "playing" && guard++ < 4) {
      this.acc -= this.interval;
      this.stepFor(s, false);
    }
    s.chomp = Math.max(0, s.chomp - dt * 4);
  }

  private updateDying(dt: number) {
    this.deathT += dt;
    let anyFired = false;
    for (const ev of this.deathEvents) {
      if (!ev.fired && ev.t <= this.deathT) {
        ev.fired = true;
        anyFired = true;
        const p = this.px(ev.x, ev.y);
        this.burst(p.x, p.y, 7, { r: 103, g: 232, b: 249, s: 3.2, speed: 240, life: 0.8 });
        this.burst(p.x, p.y, 5, { r: 244, g: 114, b: 182, s: 2.6, speed: 180, life: 0.7 });
      }
    }
    if (anyFired && !this.deathAllFired && this.deathT > 0.1) {
      // keep trauma alive through the chain reaction
      if (this.trauma < 0.25) this.trauma = 0.25;
    }
    if (this.deathT > 1.45) {
      this.setState("gameover");
      const qualified = qualifies(this.score);
      this.cbs.onGameOver({
        score: this.score,
        apples: this.apples,
        maxCombo: this.maxCombo,
        qualified,
      });
    }
  }

  private updateDemo(dt: number) {
    const d = this.demo;
    if (d.respawn > 0) {
      d.respawn -= dt;
      if (d.respawn <= 0) this.resetDemo();
      return;
    }
    d.acc += dt;
    if (d.acc >= 0.16) {
      d.acc -= 0.16;
      this.demoAI(d);
      this.stepFor(d, true);
    }
    d.chomp = Math.max(0, d.chomp - dt * 4);
  }

  private demoAI(d: SnakeState) {
    const head = d.cells[0];
    const food = this.food ?? { x: 0, y: 0 };
    const cands: DirName[] = [d.dir, LEFT_OF[d.dir], RIGHT_OF[d.dir]];
    const safe = cands.filter((dir) => {
      const v = DIRS[dir];
      const cx = wrap(head.x + v.x);
      const cy = wrap(head.y + v.y);
      const last = d.cells.length - 1;
      return !d.cells.some((c, i) => i < last && c.x === cx && c.y === cy);
    });
    if (!safe.length) {
      d.dirs.push(d.dir);
      return;
    }
    const dist = (dir: DirName) => {
      const v = DIRS[dir];
      const cx = wrap(head.x + v.x);
      const cy = wrap(head.y + v.y);
      return Math.abs(cx - food.x) + Math.abs(cy - food.y);
    };
    const best = [...safe].sort((a, b) => dist(a) - dist(b))[0];
    d.dirs.push(Math.random() < 0.12 ? safe[(Math.random() * safe.length) | 0] : best);
  }

  /* ================= stepping ================= */

  private stepFor(s: SnakeState, isDemo: boolean) {
    while (s.dirs.length) {
      const d = s.dirs.shift()!;
      if (d !== OPPOSITE[s.dir] && d !== s.dir) {
        s.dir = d;
        break;
      }
    }
    const v = DIRS[s.dir];
    const head = s.cells[0];
    const nx = wrap(head.x + v.x);
    const ny = wrap(head.y + v.y);

    // what did we hit?
    const eatApple = !!this.food && this.food.x === nx && this.food.y === ny;
    const eatGold = !!this.gold && this.gold.x === nx && this.gold.y === ny;
    const eatKind = eatApple ? "apple" : eatGold ? "gold" : "none";
    let pow: FieldPower | null = null;
    if (!isDemo && this.fieldPow && this.fieldPow.x === nx && this.fieldPow.y === ny) {
      pow = this.fieldPow;
    }

    // collision
    const ghost = !isDemo && this.ghost > 0;
    let dead = false;
    if (!ghost) {
      const willGrow = eatKind !== "none" || s.grow > 0;
      const tail = s.cells.length - 1;
      for (let i = 0; i < s.cells.length; i++) {
        if (i === tail && !willGrow) continue;
        if (s.cells[i].x === nx && s.cells[i].y === ny) {
          dead = true;
          break;
        }
      }
    }

    s.prev = s.cells.map((c) => ({ ...c }));
    s.cells.unshift({ x: nx, y: ny });
    if (eatKind !== "none") s.grow += 1;
    if (s.grow > 0) s.grow--;
    else s.cells.pop();
    s.chomp = 1;

    if (dead) {
      if (isDemo) {
        const p = this.px(nx, ny);
        this.burst(p.x, p.y, 16, { r: 103, g: 232, b: 249, s: 3, speed: 200, life: 0.9 });
        this.burst(p.x, p.y, 10, { r: 244, g: 114, b: 182, s: 2.4, speed: 150, life: 0.8 });
        s.respawn = 1.1;
        s.cells = [];
        s.prev = [];
        this.resetFood();
        return;
      }
      this.die();
      return;
    }

    if (eatApple && !isDemo) this.handleApple(nx, ny);
    if (eatGold && !isDemo) this.handleGold(nx, ny);
    if (eatApple && isDemo) {
      const p = this.px(nx, ny);
      this.burst(p.x, p.y, 6, { r: 244, g: 114, b: 182, s: 2.4, speed: 130, life: 0.7 });
      this.resetFood();
    }
    if (pow) this.handlePower(pow);
  }

  private handleApple(x: number, y: number) {
    this.combo = this.comboTimer > 0 ? Math.min(9, this.combo + 1) : 1;
    this.comboTimer = COMBO_WINDOW;
    this.maxCombo = Math.max(this.maxCombo, this.combo);
    this.apples++;
    const mult = this.combo * (this.x2 > 0 ? 2 : 1);
    const points = 10 * mult;
    this.score += points;
    const p = this.px(x, y);
    audio.eat(this.combo);
    this.burst(p.x, p.y, 14 + this.combo * 2, { r: 244, g: 114, b: 182, s: 3, speed: 210, life: 0.75 });
    this.burst(p.x, p.y, 5, { r: 255, g: 255, b: 255, s: 2.2, speed: 120, life: 0.5 });
    this.ring(p.x, p.y, this.cell * (4 + this.combo * 0.5), "rgba(244,114,182,0.9)", 3);
    this.shake(0.14 + Math.min(0.14, this.combo * 0.015));
    this.popup(`+${points}${mult > 1 ? `  ×${mult}` : ""}`, p.x, p.y - this.cell * 1.4, this.x2 > 0 ? "#fde68a" : "#f9a8d4", Math.round(this.cell * (0.72 + this.combo * 0.05)));
    if (this.combo >= 3 && this.combo === this.maxCombo && this.combo % 3 === 0) {
      this.popup(`COMBO ×${this.combo}!`, this.w / 2, this.h / 2 - this.board * 0.16, "#67e8f9", Math.round(this.cell * 1.1));
    }
    if (!this.bestCelebrated && this.best > 0 && this.score > this.best) {
      this.bestCelebrated = true;
      this.popup("★ NEW BEST ★", this.w / 2, this.h / 2 - this.board * 0.28, "#fbbf24", Math.round(this.cell * 1.3));
      audio.best();
    }
    this.popScore();
    this.resetFood();
  }

  private handleGold(x: number, y: number) {
    this.comboTimer = COMBO_WINDOW;
    this.combo = Math.min(9, this.combo + 1);
    this.maxCombo = Math.max(this.maxCombo, this.combo);
    this.apples++;
    const mult = this.combo * (this.x2 > 0 ? 2 : 1);
    const points = 50 * mult;
    this.score += points;
    const p = this.px(x, y);
    audio.gold();
    this.burst(p.x, p.y, 26, { r: 251, g: 191, b: 36, s: 3.6, speed: 260, life: 1 });
    this.burst(p.x, p.y, 12, { r: 255, g: 255, b: 255, s: 2.4, speed: 160, life: 0.7 });
    this.ring(p.x, p.y, this.board * 0.32, "rgba(251,191,36,0.9)", 4);
    this.popup(`GOLD! +${points}${mult > 1 ? `  ×${mult}` : ""}`, p.x, p.y - this.cell * 1.6, "#fde68a", Math.round(this.cell * 1));
    this.shake(0.3);
    this.flash(0.16, "251,191,36");
    this.gold = null;
    this.goldAt = this.time + rnd(14, 22);
    this.popScore();
  }

  private handlePower(pow: FieldPower) {
    this.fieldPow = null;
    this.powAt = this.time + rnd(6.5, 10.5);
    const p = this.px(pow.x, pow.y);
    if (pow.kind === "slow") this.slow = POWER_DUR.slow;
    if (pow.kind === "ghost") this.ghost = POWER_DUR.ghost;
    if (pow.kind === "x2") this.x2 = POWER_DUR.x2;
    audio.power();
    const col = pow.kind === "slow" ? "103,232,249" : pow.kind === "ghost" ? "230,235,255" : "251,191,36";
    this.burst(p.x, p.y, 20, { r: +col.split(",")[0], g: +col.split(",")[1], b: +col.split(",")[2], s: 3.4, speed: 230, life: 0.9 });
    this.ring(p.x, p.y, this.cell * 6, `rgba(${col},0.9)`, 4);
    const label = pow.kind === "slow" ? "SLOW-MO" : pow.kind === "ghost" ? "GHOST" : "×2 POINTS";
    this.popup(label, p.x, p.y - this.cell * 1.6, `rgb(${col})`, Math.round(this.cell * 0.95));
    this.shake(0.24);
    this.popScore();
  }

  private die() {
    this.setState("dying");
    this.deathT = 0;
    this.deathAllFired = false;
    this.deathEvents = [];
    const cells = this.snake.cells;
    const head = cells[0];
    const hp = this.px(head.x, head.y);
    this.deathEvents.push({ t: 0.02, x: head.x, y: head.y, fired: false });
    for (let i = 1; i < cells.length; i++) {
      this.deathEvents.push({ t: 0.1 + i * 0.024, x: cells[i].x, y: cells[i].y, fired: false });
    }
    this.burst(hp.x, hp.y, 34, { r: 103, g: 232, b: 249, s: 4, speed: 320, life: 1.1 });
    this.burst(hp.x, hp.y, 18, { r: 244, g: 114, b: 182, s: 3, speed: 240, life: 1 });
    this.ring(hp.x, hp.y, this.cell * 8, "rgba(255,80,120,0.9)", 5);
    this.flashA = 0.5;
    this.flashColor = "255,64,96";
    this.trauma = 0.75;
    audio.stopMusic();
    audio.death();
  }

  /* ================= fx helpers ================= */

  private px(gx: number, gy: number) {
    return { x: this.bx + (gx + 0.5) * this.cell, y: this.by + (gy + 0.5) * this.cell };
  }

  private shake(amount: number) {
    this.trauma = Math.min(1, this.trauma + amount);
  }

  private flash(a: number, color: string) {
    this.flashA = Math.max(this.flashA, a);
    this.flashColor = color;
  }

  private burst(
    x: number,
    y: number,
    count: number,
    opt: { r: number; g: number; b: number; s: number; speed: number; life: number; grav?: number }
  ) {
    let spawned = 0;
    for (const p of this.particles) {
      if (spawned >= count) break;
      if (p.alive) continue;
      spawned++;
      const a = rnd(0, Math.PI * 2);
      const sp = rnd(opt.speed * 0.35, opt.speed);
      p.alive = true;
      p.x = x;
      p.y = y;
      p.vx = Math.cos(a) * sp;
      p.vy = Math.sin(a) * sp;
      p.maxLife = p.life = opt.life * rnd(0.6, 1);
      p.size = opt.s * rnd(0.6, 1.3);
      p.r = opt.r;
      p.g = opt.g;
      p.b = opt.b;
      p.grav = opt.grav ?? 160;
      p.drag = 3.2;
    }
  }

  private popup(text: string, x: number, y: number, color: string, size: number) {
    this.popups.push({ x, y, color, text, size, life: 0.95, maxLife: 0.95 });
    if (this.popups.length > 14) this.popups.shift();
  }

  private ring(x: number, y: number, maxR: number, color: string, width: number) {
    this.rings.push({ x, y, maxR, life: 0.5, maxLife: 0.5, color, width });
    if (this.rings.length > 8) this.rings.shift();
  }

  private updateFx(dt: number) {
    for (const p of this.particles) {
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        continue;
      }
      p.vy += p.grav * dt;
      const dr = 1 - Math.min(0.9, p.drag * dt);
      p.vx *= dr;
      p.vy *= dr;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (let i = this.rings.length - 1; i >= 0; i--) {
      this.rings[i].life -= dt;
      if (this.rings[i].life <= 0) this.rings.splice(i, 1);
    }
    for (let i = this.popups.length - 1; i >= 0; i--) {
      const t = this.popups[i];
      t.life -= dt;
      t.y -= dt * 46;
      if (t.life <= 0) this.popups.splice(i, 1);
    }
    if (this.food && Math.random() < dt * 3) {
      const p = this.px(this.food.x, this.food.y);
      for (const q of this.particles) {
        if (!q.alive) {
          q.alive = true;
          q.x = p.x + rnd(-4, 4);
          q.y = p.y + rnd(-4, 4);
          q.vx = rnd(-14, 14);
          q.vy = rnd(-44, -20);
          q.maxLife = q.life = rnd(0.4, 0.8);
          q.size = rnd(1, 2.2);
          q.r = 249;
          q.g = 168;
          q.b = 212;
          q.grav = 0;
          q.drag = 1;
          break;
        }
      }
    }
  }

  private updateEmbers(dt: number) {
    for (const e of this.embers) {
      e.y -= e.vy * dt;
      if (e.y < -0.03) {
        e.y = 1.03;
        e.x = Math.random();
      }
    }
  }

  /* ================= input ================= */

  private onKey = (e: KeyboardEvent) => {
    const tgt = e.target as HTMLElement | null;
    if (tgt && (tgt.tagName === "INPUT" || tgt.tagName === "TEXTAREA")) return;
    const k = e.key;
    const dirMap: Record<string, DirName> = {
      ArrowUp: "up", w: "up", W: "up",
      ArrowDown: "down", s: "down", S: "down",
      ArrowLeft: "left", a: "left", A: "left",
      ArrowRight: "right", d: "right", D: "right",
    };
    if (k === "m" || k === "M") {
      audio.unlock();
      audio.setMuted(!audio.muted);
      this.cbs.onMuteChange(audio.muted);
      return;
    }
    if (dirMap[k]) {
      e.preventDefault();
      audio.unlock();
      this.queueDir(dirMap[k]);
      return;
    }
    if (k === " " || k === "Enter") {
      if (e.repeat) return;
      if (this.state === "menu" || this.state === "gameover") {
        e.preventDefault();
        this.startGame();
      } else if (this.state === "paused") {
        e.preventDefault();
        this.resume();
      }
      return;
    }
    if (k === "p" || k === "P" || k === "Escape") {
      if (e.repeat) return;
      if (this.state === "playing" || this.state === "paused") {
        e.preventDefault();
        this.togglePause();
      }
    }
  };

  private onPointerDown = (e: PointerEvent) => {
    audio.unlock();
    if (e.pointerType === "mouse" && e.button !== 0) return;
    this.pointerActive = true;
    this.pointerId = e.pointerId;
    this.anchorX = e.clientX;
    this.anchorY = e.clientY;
    try {
      this.canvas.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.pointerActive || e.pointerId !== this.pointerId) return;
    const dx = e.clientX - this.anchorX;
    const dy = e.clientY - this.anchorY;
    const TH = 26;
    if (Math.abs(dx) < TH && Math.abs(dy) < TH) return;
    if (Math.abs(dx) > Math.abs(dy)) this.queueDir(dx > 0 ? "right" : "left");
    else this.queueDir(dy > 0 ? "down" : "up");
    this.anchorX = e.clientX;
    this.anchorY = e.clientY;
  };

  private onPointerUp = (e: PointerEvent) => {
    if (e.pointerId !== this.pointerId) return;
    this.pointerActive = false;
  };

  private onVisibility = () => {
    if (document.hidden && this.state === "playing") {
      this.setState("paused");
      audio.stopMusic();
    }
  };

  private onBlur = () => {
    if (this.state === "playing") {
      this.setState("paused");
      audio.stopMusic();
    }
  };

  /* ================= resize / hud ================= */

  private resize() {
    const parent = this.canvas.parentElement;
    if (!parent) return;
    const w = parent.clientWidth;
    const h = parent.clientHeight;
    if (w === 0 || h === 0) return;
    this.w = w;
    this.h = h;
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = Math.round(w * this.dpr);
    this.canvas.height = Math.round(h * this.dpr);
    this.board = Math.min(w, h) - 20;
    this.bx = (w - this.board) / 2;
    this.by = (h - this.board) / 2;
    this.cell = this.board / N;

    const bg = this.ctx.createRadialGradient(w / 2, h * 0.32, 10, w / 2, h * 0.5, Math.max(w, h) * 0.75);
    bg.addColorStop(0, "#140a33");
    bg.addColorStop(0.55, "#0a0424");
    bg.addColorStop(1, "#04010e");
    this.bgGrad = bg;

    // static grid layer
    const gl = document.createElement("canvas");
    gl.width = this.canvas.width;
    gl.height = this.canvas.height;
    const g = gl.getContext("2d")!;
    g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    g.strokeStyle = "rgba(103,232,249,0.07)";
    g.lineWidth = 1;
    for (let i = 0; i <= N; i++) {
      const x = this.bx + i * this.cell;
      const y = this.by + i * this.cell;
      g.beginPath();
      g.moveTo(x, this.by);
      g.lineTo(x, this.by + this.board);
      g.stroke();
      g.beginPath();
      g.moveTo(this.bx, y);
      g.lineTo(this.bx + this.board, y);
      g.stroke();
    }
    // board border glow
    g.strokeStyle = "rgba(103,232,249,0.5)";
    g.lineWidth = 2;
    g.strokeRect(this.bx - 3, this.by - 3, this.board + 6, this.board + 6);
    g.strokeStyle = "rgba(103,232,249,0.14)";
    g.lineWidth = 7;
    g.strokeRect(this.bx - 6, this.by - 6, this.board + 12, this.board + 12);
    // corner accents
    g.strokeStyle = "rgba(232,121,249,0.8)";
    g.lineWidth = 3;
    const L = this.cell * 1.1;
    const corners: [number, number, number, number][] = [
      [this.bx - 3, this.by - 3, 1, 1],
      [this.bx + this.board + 3, this.by - 3, -1, 1],
      [this.bx - 3, this.by + this.board + 3, 1, -1],
      [this.bx + this.board + 3, this.by + this.board + 3, -1, -1],
    ];
    for (const [cx, cy, sx, sy] of corners) {
      g.beginPath();
      g.moveTo(cx, cy + sy * L);
      g.lineTo(cx, cy);
      g.lineTo(cx + sx * L, cy);
      g.stroke();
    }
    this.gridLayer = gl;
  }

  private loadBest(): number {
    try {
      const raw = localStorage.getItem("ns_scores_v1");
      if (!raw) return 0;
      const list = JSON.parse(raw) as { score: number }[];
      return list.length ? Math.max(...list.map((e) => e.score)) : 0;
    } catch {
      return 0;
    }
  }

  private popScore() {
    const el = this.hud.score;
    if (!el) return;
    el.classList.remove("score-pop");
    void el.offsetWidth;
    el.classList.add("score-pop");
  }

  private cacheHud() {
    const ids = [
      "hud-score", "hud-best", "hud-combo", "hud-combo-num", "hud-combo-bar",
      "hud-pow-slow", "hud-pow-slow-bar", "hud-pow-ghost", "hud-pow-ghost-bar",
      "hud-pow-x2", "hud-pow-x2-bar",
    ];
    for (const id of ids) this.hud[id] = document.getElementById(id);
  }

  private setHud(id: string, value: string) {
    const el = this.hud[id];
    if (!el) return;
    if (this.hudCache[id] === value) return;
    this.hudCache[id] = value;
    el.textContent = value;
  }

  private setHudStyle(id: string, prop: string, value: string) {
    const el = this.hud[id];
    if (!el) return;
    const k = `${id}:${prop}`;
    if (this.hudCache[k] === value) return;
    this.hudCache[k] = value;
    (el.style as unknown as Record<string, string>)[prop] = value;
  }

  private writeHud() {
    if (!this.hud.score) this.cacheHud();
    const showBest = Math.max(this.best, this.score);
    this.setHud("hud-score", String(this.score));
    this.setHud("hud-best", String(showBest));
    const comboActive = this.combo >= 2 && (this.state === "playing" || this.state === "countdown");
    this.setHudStyle("hud-combo", "opacity", comboActive ? "1" : "0");
    this.setHudStyle("hud-combo", "transform", comboActive ? "translateY(0) scale(1)" : "translateY(-8px) scale(0.9)");
    this.setHud("hud-combo-num", `×${this.combo}`);
    this.setHudStyle("hud-combo-bar", "transform", `scaleX(${clamp(this.comboTimer / COMBO_WINDOW, 0, 1)})`);
    const pows: [string, number, number][] = [
      ["slow", this.slow, POWER_DUR.slow],
      ["ghost", this.ghost, POWER_DUR.ghost],
      ["x2", this.x2, POWER_DUR.x2],
    ];
    for (const [name, t, dur] of pows) {
      const on = t > 0;
      this.setHudStyle(`hud-pow-${name}`, "opacity", on ? "1" : "0");
      this.setHudStyle(`hud-pow-${name}`, "transform", on ? "translateY(0)" : "translateY(10px)");
      this.setHudStyle(`hud-pow-${name}-bar`, "transform", `scaleX(${clamp(t / dur, 0, 1)})`);
    }
  }

  /* ================= render ================= */

  private render() {
    const { ctx, w, h, dpr } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = this.bgGrad ?? "#060213";
    ctx.fillRect(0, 0, w, h);

    // embers
    ctx.globalCompositeOperation = "lighter";
    for (const e of this.embers) {
      const ex = e.x * w + Math.sin(this.time * 0.55 + e.phase) * 14;
      const ey = e.y * h;
      ctx.globalAlpha = 0.10 + 0.06 * Math.sin(this.time * 1.4 + e.phase);
      ctx.drawImage(e.gold ? this.glowGold : this.glowCyan, ex - e.size * 4, ey - e.size * 4, e.size * 8, e.size * 8);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";

    // shake transform
    ctx.save();
    const amp = this.trauma * this.trauma;
    if (amp > 0.001) {
      const dx = (Math.random() * 2 - 1) * amp * 13;
      const dy = (Math.random() * 2 - 1) * amp * 13;
      const rot = (Math.random() * 2 - 1) * amp * 0.012;
      ctx.translate(w / 2 + dx, h / 2 + dy);
      ctx.rotate(rot);
      ctx.translate(-w / 2, -h / 2);
    }

    if (this.gridLayer) ctx.drawImage(this.gridLayer, 0, 0, w, h);

    // soft floor glow inside board
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.05;
    ctx.drawImage(this.glowPurple, this.bx + this.board / 2 - this.board * 0.7, this.by + this.board / 2 - this.board * 0.7, this.board * 1.4, this.board * 1.4);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";

    const demoMode = this.state === "menu";
    if (this.state === "paused" || this.state === "gameover") {
      // draw frozen world behind overlay
      this.drawFood();
      this.drawGold();
      this.drawPower();
      this.drawSnake(this.snake, false);
    } else {
      this.drawFood();
      this.drawGold();
      this.drawPower();
      this.drawSnake(demoMode ? this.demo : this.snake, demoMode);
    }

    // particles
    ctx.globalCompositeOperation = "lighter";
    for (const p of this.particles) {
      if (!p.alive) continue;
      const t = p.life / p.maxLife;
      ctx.globalAlpha = t * 0.9;
      ctx.fillStyle = `rgb(${p.r},${p.g},${p.b})`;
      const s = p.size * (0.6 + t * 0.6);
      ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
    }
    // rings
    for (const r of this.rings) {
      const t01 = 1 - r.life / r.maxLife;
      const rr = r.maxR * easeOutCubic(t01);
      ctx.globalAlpha = (r.life / r.maxLife) * 0.8;
      ctx.strokeStyle = r.color;
      ctx.lineWidth = r.width * (r.life / r.maxLife) + 1;
      ctx.beginPath();
      ctx.arc(r.x, r.y, Math.max(0.5, rr), 0, Math.PI * 2);
      ctx.stroke();
    }
    // popups
    ctx.globalCompositeOperation = "source-over";
    for (const t of this.popups) {
      const age = t.maxLife - t.life;
      const scale = Math.min(1, age / 0.1) * (1 + 0.14 * easeOutBack(Math.min(1, age / 0.25)));
      ctx.globalAlpha = Math.min(1, t.life / 0.35);
      ctx.font = `700 ${Math.round(t.size * scale)}px ${FONT_BODY}`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(4,1,16,0.75)";
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;

    // countdown numbers
    if (this.state === "countdown") {
      const n = Math.max(1, Math.ceil(this.countT / 0.3));
      const frac = (this.countT % 0.3) / 0.3;
      const scale = 0.7 + 0.5 * easeOutBack(Math.min(1, (1 - frac) * 2));
      ctx.globalAlpha = Math.min(1, (1 - frac) * 2.4);
      ctx.font = `900 ${Math.round(this.board * 0.3 * scale)}px ${FONT_DISPLAY}`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = "#a5f3fc";
      ctx.shadowColor = "rgba(34,211,238,0.9)";
      ctx.shadowBlur = 30;
      ctx.fillText(String(n), w / 2, h / 2);
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
    }

    ctx.restore();

    // slow-mo tint
    if (this.slow > 0 && (this.state === "playing" || this.state === "paused")) {
      ctx.fillStyle = "rgba(56,189,248,0.05)";
      ctx.fillRect(0, 0, w, h);
    }
    // flash
    if (this.flashA > 0.003) {
      ctx.fillStyle = `rgba(${this.flashColor},${this.flashA.toFixed(3)})`;
      ctx.fillRect(0, 0, w, h);
    }
  }

  private drawFood() {
    const { ctx } = this;
    if (!this.food) return;
    const p = this.px(this.food.x, this.food.y);
    const t = this.time;
    const pulse = 1 + 0.13 * Math.sin(t * 5.2);
    const born = Math.min(1, this.foodAge * 3);
    const spawn = easeOutBack(born);
    const size = this.cell * 0.36 * pulse * spawn;
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.75;
    ctx.drawImage(this.glowPink, p.x - size * 3.4, p.y - size * 3.4, size * 6.8, size * 6.8);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    if (size < 1) return;
    const grad = ctx.createRadialGradient(p.x - size * 0.3, p.y - size * 0.35, size * 0.1, p.x, p.y, size * 1.15);
    grad.addColorStop(0, "#fbcfe8");
    grad.addColorStop(0.45, "#f472b6");
    grad.addColorStop(1, "#be185d");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
    ctx.fill();
    // little stem
    ctx.strokeStyle = "#34d399";
    ctx.lineWidth = Math.max(1.5, this.cell * 0.07);
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(p.x, p.y - size * 0.9);
    ctx.quadraticCurveTo(p.x + size * 0.3, p.y - size * 1.5, p.x + size * 0.55, p.y - size * 1.35);
    ctx.stroke();
    // leaf
    ctx.fillStyle = "#4ade80";
    ctx.beginPath();
    ctx.ellipse(p.x + size * 0.62, p.y - size * 1.42, size * 0.34, size * 0.16, -0.5, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawGold() {
    const { ctx } = this;
    if (!this.gold) return;
    const bl = this.gold.age > this.gold.life - 2.5 ? 0.5 + 0.5 * Math.sin(this.time * 14) : 1;
    const p = this.px(this.gold.x, this.gold.y);
    const born = easeOutBack(Math.min(1, this.gold.age * 3));
    const s = this.cell * 0.42 * born * (1 + 0.06 * Math.sin(this.time * 6));
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.8 * bl;
    ctx.drawImage(this.glowGold, p.x - s * 4, p.y - s * 4, s * 8, s * 8);
    ctx.globalAlpha = bl;
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = "#fde68a";
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = Math.max(1.5, this.cell * 0.08);
    this.starPath(p.x, p.y, 5, s, s * 0.45, this.time * 1.4);
    ctx.fill();
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  private drawPower() {
    const { ctx } = this;
    if (!this.fieldPow) return;
    const pow = this.fieldPow;
    const p = this.px(pow.x, pow.y);
    const bl = pow.age > pow.life - 2.5 ? 0.45 + 0.55 * Math.abs(Math.sin(this.time * 8)) : 1;
    const born = easeOutBack(Math.min(1, pow.age * 3.4));
    const s = this.cell * 0.46 * born;
    ctx.globalAlpha = bl;
    ctx.globalCompositeOperation = "lighter";
    ctx.drawImage(this.glowCyan, p.x - s * 3.2, p.y - s * 3.2, s * 6.4, s * 6.4);
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = "rgba(8,4,26,0.9)";
    ctx.strokeStyle = POWER_COLOR[pow.kind] + "0.95)";
    ctx.lineWidth = 2.5;
    this.rrPath(p.x, p.y, s, this.cell * 0.16);
    ctx.fill();
    ctx.stroke();
    // icon
    const col = POWER_COLOR[pow.kind] + "1)";
    ctx.fillStyle = col;
    ctx.strokeStyle = col;
    const is = s * 0.62;
    if (pow.kind === "slow") {
      ctx.beginPath();
      ctx.moveTo(p.x - is, p.y - is * 0.78);
      ctx.lineTo(p.x + is, p.y - is * 0.78);
      ctx.lineTo(p.x, p.y);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(p.x - is, p.y + is * 0.78);
      ctx.lineTo(p.x + is, p.y + is * 0.78);
      ctx.lineTo(p.x, p.y);
      ctx.closePath();
      ctx.fill();
    } else if (pow.kind === "ghost") {
      ctx.beginPath();
      ctx.arc(p.x, p.y - is * 0.18, is * 0.62, Math.PI, 0);
      ctx.lineTo(p.x + is * 0.62, p.y + is * 0.62);
      ctx.quadraticCurveTo(p.x + is * 0.3, p.y + is * 0.34, p.x, p.y + is * 0.62);
      ctx.quadraticCurveTo(p.x - is * 0.3, p.y + is * 0.9, p.x - is * 0.62, p.y + is * 0.62);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(8,4,26,0.95)";
      ctx.beginPath();
      ctx.arc(p.x - is * 0.26, p.y - is * 0.24, is * 0.13, 0, Math.PI * 2);
      ctx.arc(p.x + is * 0.26, p.y - is * 0.24, is * 0.13, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.font = `800 ${Math.round(s * 1.05)}px ${FONT_DISPLAY}`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("2×", p.x, p.y + s * 0.04);
    }
    ctx.globalAlpha = 1;
  }

  private drawSnake(s: SnakeState, demoMode: boolean) {
    const { ctx } = this;
    if (!s.cells.length) return;
    const n = s.cells.length;
    const t = clamp(this.state === "paused" || this.state === "gameover" ? 1 : this.acc / this.interval, 0, 1);
    const pts: { x: number; y: number }[] = new Array(n);
    for (let i = 0; i < n; i++) {
      const c = s.cells[i];
      const p0 = s.prev[Math.min(i, s.prev.length - 1)] ?? c;
      let lx = p0.x + (c.x - p0.x) * t;
      let ly = p0.y + (c.y - p0.y) * t;
      if (Math.abs(c.x - p0.x) > 1) lx = c.x;
      if (Math.abs(c.y - p0.y) > 1) ly = c.y;
      pts[i] = { x: this.bx + (lx + 0.5) * this.cell, y: this.by + (ly + 0.5) * this.cell };
    }

    const ghost = !demoMode && this.ghost > 0;
    const alpha = ghost ? 0.55 + 0.1 * Math.sin(this.time * 22) : demoMode ? 0.9 : 1;
    ctx.globalAlpha = alpha;

    // glow trail
    ctx.globalCompositeOperation = "lighter";
    ctx.strokeStyle = "rgba(34,211,238,0.16)";
    ctx.lineWidth = this.cell * 1.02;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < n; i++) ctx.lineTo(pts[i].x, pts[i].y);
    ctx.stroke();
    if (n > 1) {
      ctx.strokeStyle = "rgba(232,121,249,0.07)";
      ctx.lineWidth = this.cell * 0.6;
      ctx.beginPath();
      ctx.moveTo(pts[0].x + 2, pts[0].y + 2);
      for (let i = 1; i < n; i++) ctx.lineTo(pts[i].x + 2, pts[i].y + 2);
      ctx.stroke();
    }
    ctx.globalCompositeOperation = "source-over";

    // body
    const rBody = this.cell * 0.415;
    for (let i = n - 1; i >= 1; i--) {
      const idx = Math.min(47, Math.floor((i / Math.max(1, n - 1)) * 47));
      ctx.fillStyle = PALETTE[idx];
      ctx.beginPath();
      ctx.arc(pts[i].x, pts[i].y, rBody, 0, Math.PI * 2);
      ctx.fill();
    }
    // head
    const chomp = s.chomp;
    const headR = this.cell * (0.52 + 0.16 * chomp);
    const hp = pts[0];
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = alpha * 0.5;
    const gs = headR * 4.6;
    ctx.drawImage(this.glowCyan, hp.x - gs / 2, hp.y - gs / 2, gs, gs);
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = alpha;
    const hg = ctx.createRadialGradient(hp.x - headR * 0.3, hp.y - headR * 0.35, headR * 0.15, hp.x, hp.y, headR * 1.25);
    hg.addColorStop(0, this.x2 > 0 && !demoMode ? "#fef3c7" : "#e0fbff");
    hg.addColorStop(0.6, this.x2 > 0 && !demoMode ? "#fbbf24" : "#22d3ee");
    hg.addColorStop(1, "#0e7490");
    ctx.fillStyle = hg;
    ctx.beginPath();
    ctx.arc(hp.x, hp.y, headR, 0, Math.PI * 2);
    ctx.fill();

    // face: eyes + tongue
    const v = DIRS[s.dir];
    const px = -v.y;
    const py = v.x;
    const blink = (this.time * 1.15) % 3.6 < 0.11;
    const eyeOff = headR * 0.42;
    const eyeR = headR * 0.3;
    for (const side of [-1, 1]) {
      const ex = hp.x + v.x * eyeOff * 0.75 + px * eyeOff * side;
      const ey = hp.y + v.y * eyeOff * 0.75 + py * eyeOff * side;
      if (blink || demoMode === false && this.state === "dying") {
        ctx.strokeStyle = "#062033";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(ex - eyeR * 0.7, ey);
        ctx.lineTo(ex + eyeR * 0.7, ey);
        ctx.stroke();
      } else {
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(ex, ey, eyeR, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#083344";
        ctx.beginPath();
        ctx.arc(ex + v.x * eyeR * 0.38, ey + v.y * eyeR * 0.38, eyeR * 0.55, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    if (!blink && (this.time * 0.9) % 2.8 < 0.16) {
      const tx = hp.x + v.x * (headR * 1.15);
      const ty = hp.y + v.y * (headR * 1.15);
      ctx.strokeStyle = "#fb7185";
      ctx.lineWidth = Math.max(2, this.cell * 0.09);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(hp.x + v.x * headR * 0.85, hp.y + v.y * headR * 0.85);
      ctx.lineTo(tx, ty);
      ctx.lineTo(tx + v.x * this.cell * 0.18 + px * this.cell * 0.1, ty + v.y * this.cell * 0.18 + py * this.cell * 0.1);
      ctx.moveTo(tx, ty);
      ctx.lineTo(tx + v.x * this.cell * 0.18 - px * this.cell * 0.1, ty + v.y * this.cell * 0.18 - py * this.cell * 0.1);
      ctx.stroke();
    }

    // ghost outline
    if (ghost) {
      ctx.globalAlpha = 0.7;
      ctx.strokeStyle = "rgba(235,240,255,0.85)";
      ctx.lineWidth = 2;
      ctx.setLineDash([7, 7]);
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < n; i++) ctx.lineTo(pts[i].x, pts[i].y);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    ctx.globalAlpha = 1;
  }

  private rrPath(x: number, y: number, s: number, r: number) {
    const { ctx } = this;
    ctx.beginPath();
    ctx.moveTo(x - s + r, y - s);
    ctx.lineTo(x + s - r, y - s);
    ctx.quadraticCurveTo(x + s, y - s, x + s, y - s + r);
    ctx.lineTo(x + s, y + s - r);
    ctx.quadraticCurveTo(x + s, y + s, x + s - r, y + s);
    ctx.lineTo(x - s + r, y + s);
    ctx.quadraticCurveTo(x - s, y + s, x - s, y + s - r);
    ctx.lineTo(x - s, y - s + r);
    ctx.quadraticCurveTo(x - s, y - s, x - s + r, y - s);
    ctx.closePath();
  }

  private starPath(x: number, y: number, spikes: number, outer: number, inner: number, rot: number) {
    const { ctx } = this;
    ctx.beginPath();
    for (let i = 0; i < spikes * 2; i++) {
      const r = i % 2 === 0 ? outer : inner;
      const a = rot + (i * Math.PI) / spikes;
      const px = x + Math.cos(a) * r;
      const py = y + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
  }
}
