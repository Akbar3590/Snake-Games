export interface ScoreEntry {
  id: string;
  name: string;
  score: number;
  apples: number;
  maxCombo: number;
  date: number;
}

const SCORES_KEY = "ns_scores_v1";
const NAME_KEY = "ns_name";
export const MAX_ENTRIES = 8;

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(SCORES_KEY);
    if (!raw) return [];
    const list = JSON.parse(raw) as ScoreEntry[];
    if (!Array.isArray(list)) return [];
    return list
      .filter((e) => e && typeof e.score === "number")
      .sort((a, b) => b.score - a.score)
      .slice(0, MAX_ENTRIES);
  } catch {
    return [];
  }
}

function save(list: ScoreEntry[]) {
  try {
    localStorage.setItem(SCORES_KEY, JSON.stringify(list));
  } catch {
    /* ignore */
  }
}

export function qualifies(score: number): boolean {
  if (score <= 0) return false;
  const list = loadScores();
  if (list.length < MAX_ENTRIES) return true;
  return score > list[list.length - 1].score;
}

export function addScore(entry: Omit<ScoreEntry, "id" | "date">): {
  list: ScoreEntry[];
  id: string;
  rank: number;
} {
  const id = `${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`;
  const full: ScoreEntry = { ...entry, id, date: Date.now() };
  const list = [...loadScores(), full].sort((a, b) => b.score - a.score).slice(0, MAX_ENTRIES);
  const rank = list.findIndex((e) => e.id === id);
  save(list);
  return { list, id, rank: rank === -1 ? -1 : rank + 1 };
}

export function renameScore(id: string, name: string): ScoreEntry[] {
  const list = loadScores().map((e) => (e.id === id ? { ...e, name: name || "???" } : e));
  save(list);
  return list;
}

export function loadName(): string {
  try {
    return (localStorage.getItem(NAME_KEY) || "ACE").slice(0, 3).toUpperCase();
  } catch {
    return "ACE";
  }
}

export function saveName(name: string) {
  try {
    localStorage.setItem(NAME_KEY, name.slice(0, 3).toUpperCase());
  } catch {
    /* ignore */
  }
}
