import type { DirName, GameResult } from "../game/engine";
import type { ScoreEntry } from "../game/highscores";

/* ---------------- score table ---------------- */

export function ScoreTable({
  scores,
  highlightId,
  limit = 8,
}: {
  scores: ScoreEntry[];
  highlightId?: string | null;
  limit?: number;
}) {
  const medal = ["text-gold", "text-slate-300", "text-amber-600"];
  return (
    <div className="w-full">
      <div className="flex items-center justify-between px-1 mb-1.5">
        <h3 className="text-[11px] tracking-[0.3em] text-cyan-300/80 font-semibold">HALL OF FAME</h3>
        <span className="text-[10px] tracking-widest text-slate-400">LOCAL TOP {limit}</span>
      </div>
      {scores.length === 0 ? (
        <p className="text-xs text-slate-400 text-center py-4 tracking-wide">
          NO RECORDS YET — BE THE FIRST 🐍
        </p>
      ) : (
        <ol className="space-y-0.5">
          {scores.slice(0, limit).map((s, i) => (
            <li
              key={s.id}
              className={`score-row ${s.id === highlightId ? "you" : i % 2 ? "bg-white/[0.03]" : ""}`}
            >
              <span
                className={`font-display text-sm font-bold ${
                  medal[i] ?? "text-slate-500"
                }`}
              >
                {i + 1}
              </span>
              <span className="text-sm tracking-[0.25em] text-slate-100 font-semibold truncate">
                {s.name}
              </span>
              <span className="font-display text-sm font-bold text-cyan-200 tabular-nums">
                {s.score.toLocaleString()}
              </span>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

/* ---------------- power legend chip ---------------- */

function LegendChip({ color, label, desc }: { color: string; label: string; desc: string }) {
  return (
    <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-white/[0.04] border border-white/10 min-w-0">
      <span
        className="w-2.5 h-2.5 rounded-sm shrink-0"
        style={{ background: color, boxShadow: `0 0 8px ${color}` }}
      />
      <div className="leading-tight min-w-0">
        <p className="text-[10px] font-display font-bold tracking-wider" style={{ color }}>
          {label}
        </p>
        <p className="text-[9px] text-slate-400 truncate">{desc}</p>
      </div>
    </div>
  );
}

/* ---------------- start screen ---------------- */

export function StartScreen({
  scores,
  best,
  isTouch,
  onStart,
}: {
  scores: ScoreEntry[];
  best: number;
  isTouch: boolean;
  onStart: () => void;
}) {
  return (
    <div className="absolute inset-0 z-40 flex p-4 overflow-y-auto">
      <div className="absolute inset-0 overlay-dim" />
      <div className="relative m-auto w-full max-w-3xl py-6 flex flex-col items-center gap-5 pop-in">
        <div className="text-center float-y">
          <p className="text-[11px] sm:text-xs tracking-[0.55em] text-fuchsia-300/90 font-semibold mb-2">
            ◢ ARCADE SNAKE REMIX ◣
          </p>
          <h1 className="neon-title text-5xl sm:text-7xl font-black leading-none tracking-wide">
            NEON
            <br className="sm:hidden" />
            <span className="sm:ml-4">SERPENT</span>
          </h1>
          {best > 0 && (
            <p className="mt-3 font-display text-sm text-amber-300 tracking-[0.3em]">
              ★ BEST&nbsp;&nbsp;{best.toLocaleString()} ★
            </p>
          )}
        </div>

        <button
          onClick={onStart}
          className="btn btn-primary text-lg sm:text-xl px-10 py-4"
          autoFocus
        >
          ▶ START GAME
        </button>
        {!isTouch && (
          <p className="text-xs text-cyan-200/70 tracking-[0.3em] blink-soft -mt-2">
            PRESS SPACE TO PLAY
          </p>
        )}

        <div className="w-full grid gap-3 sm:grid-cols-2">
          <div className="panel rounded-xl p-4">
            <h3 className="text-[11px] tracking-[0.3em] text-cyan-300/80 font-semibold mb-2">
              CONTROLS
            </h3>
            {isTouch ? (
              <p className="text-sm text-slate-200 leading-relaxed">
                <span className="text-cyan-300 font-semibold">SWIPE</span> on the board to steer
                — keep your finger down and flick to chain turns.
              </p>
            ) : (
              <p className="text-sm text-slate-200 leading-relaxed">
                <span className="text-cyan-300 font-semibold">←↑↓→ / WASD</span> steer ·{" "}
                <span className="text-cyan-300 font-semibold">P</span> pause ·{" "}
                <span className="text-cyan-300 font-semibold">SPACE</span> start / restart ·{" "}
                <span className="text-cyan-300 font-semibold">M</span> mute
              </p>
            )}
            <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">
              Eat fast to build your <span className="text-fuchsia-300">combo ×9</span>. Wrap
              through walls. Don&apos;t bite yourself.
            </p>
          </div>
          <div className="panel rounded-xl p-4">
            <h3 className="text-[11px] tracking-[0.3em] text-cyan-300/80 font-semibold mb-2">
              POWER-UPS
            </h3>
            <div className="grid grid-cols-2 gap-1.5">
              <LegendChip color="#67e8f9" label="SLOW-MO" desc="time crawls" />
              <LegendChip color="#e6ebff" label="GHOST" desc="phase through self" />
              <LegendChip color="#fbbf24" label="×2" desc="double points" />
              <LegendChip color="#fde68a" label="★ GOLD" desc="big bonus apple" />
            </div>
          </div>
        </div>

        <div className="panel rounded-xl p-4 w-full">
          <ScoreTable scores={scores} />
        </div>
      </div>
    </div>
  );
}

/* ---------------- pause screen ---------------- */

export function PauseScreen({
  onResume,
  onRestart,
  onMenu,
}: {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
}) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4">
      <div className="absolute inset-0 overlay-dim" />
      <div className="relative panel rounded-2xl p-8 flex flex-col items-center gap-4 pop-in w-full max-w-xs">
        <h2 className="neon-title text-4xl font-black tracking-widest">PAUSED</h2>
        <p className="text-[11px] tracking-[0.3em] text-slate-400">TAKE A BREATH, SERPENT</p>
        <button onClick={onResume} className="btn btn-primary w-full">
          ▶ RESUME
        </button>
        <button onClick={onRestart} className="btn btn-ghost w-full">
          ↻ RESTART
        </button>
        <button onClick={onMenu} className="btn btn-ghost w-full opacity-80">
          ⌂ MENU
        </button>
        <p className="text-[10px] text-slate-500 tracking-[0.25em]">P / ESC — RESUME</p>
      </div>
    </div>
  );
}

/* ---------------- game over ---------------- */

export function GameOverScreen({
  result,
  entryId,
  scores,
  name,
  onNameChange,
  onRestart,
  onMenu,
  isTouch,
}: {
  result: GameResult;
  entryId: string | null;
  scores: ScoreEntry[];
  name: string;
  onNameChange: (v: string) => void;
  onRestart: () => void;
  onMenu: () => void;
  isTouch: boolean;
}) {
  const isBest = entryId !== null && scores[0]?.id === entryId;
  return (
    <div className="absolute inset-0 z-40 flex p-3 overflow-y-auto">
      <div className="absolute inset-0 overlay-dim" />
      <div className="relative m-auto panel rounded-2xl p-5 sm:p-7 w-full max-w-md pop-in flex flex-col items-center gap-4">
        {isBest ? (
          <h2 className="neon-gold-title text-4xl sm:text-5xl font-black tracking-wide text-center leading-tight">
            NEW HIGH SCORE!
          </h2>
        ) : (
          <h2 className="neon-pink-title text-4xl sm:text-5xl font-black tracking-wide text-center">
            GAME OVER
          </h2>
        )}

        <div className="text-center">
          <p className="text-[10px] tracking-[0.4em] text-slate-400 mb-1">FINAL SCORE</p>
          <p className="font-display text-5xl sm:text-6xl font-black text-cyan-200 tabular-nums leading-none drop-shadow-[0_0_18px_rgba(34,211,238,0.6)]">
            {result.score.toLocaleString()}
          </p>
        </div>

        <div className="flex gap-2 w-full">
          {[
            ["APPLES", result.apples],
            ["MAX COMBO", `×${result.maxCombo}`],
            ["BEST", Math.max(result.score, scores[0]?.score ?? 0).toLocaleString()],
          ].map(([label, v]) => (
            <div
              key={label}
              className="flex-1 rounded-lg bg-white/[0.04] border border-white/10 py-2 text-center"
            >
              <p className="text-[9px] tracking-[0.25em] text-slate-400">{label}</p>
              <p className="font-display text-lg font-bold text-fuchsia-200 tabular-nums">{v}</p>
            </div>
          ))}
        </div>

        {entryId && (
          <div className="flex items-center gap-3 w-full justify-center">
            <label className="text-[10px] tracking-[0.3em] text-amber-300/90 font-semibold">
              INITIALS
            </label>
            <input
              className="initials w-24 py-1.5 text-lg"
              value={name}
              maxLength={3}
              onChange={(e) => onNameChange(e.target.value)}
              onFocus={(e) => e.target.select()}
              placeholder="AAA"
            />
          </div>
        )}

        <div className="w-full panel rounded-xl p-3" style={{ background: "rgba(4,1,16,0.5)" }}>
          <ScoreTable scores={scores} highlightId={entryId} limit={5} />
        </div>

        <div className="flex gap-2.5 w-full">
          <button onClick={onRestart} className="btn btn-primary flex-1" autoFocus>
            ↻ PLAY AGAIN
          </button>
          <button onClick={onMenu} className="btn btn-ghost">
            ⌂ MENU
          </button>
        </div>
        {!isTouch && (
          <p className="text-[10px] text-slate-500 tracking-[0.3em] -mt-1">
            SPACE — INSTANT RESTART
          </p>
        )}
      </div>
    </div>
  );
}

/* ---------------- touch pad ---------------- */

function PadArrow({ d, onDir }: { d: DirName; onDir: (d: DirName) => void }) {
  const rot = { up: 0, right: 90, down: 180, left: 270 }[d];
  return (
    <button
      className="pad-btn w-14 h-14 sm:w-16 sm:h-16"
      onPointerDown={(e) => {
        e.preventDefault();
        onDir(d);
      }}
      aria-label={d}
    >
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        style={{ transform: `rotate(${rot}deg)` }}
        fill="none"
      >
        <path d="M12 4 L19 15 H5 Z" fill="currentColor" />
      </svg>
    </button>
  );
}

export function TouchPad({ onDir }: { onDir: (d: DirName) => void }) {
  return (
    <div className="shrink-0 flex items-center justify-center py-2 px-4 select-none">
      <div
        className="grid grid-cols-3 gap-1.5"
        style={{ touchAction: "none", WebkitUserSelect: "none" }}
      >
        <div />
        <PadArrow d="up" onDir={onDir} />
        <div />
        <PadArrow d="left" onDir={onDir} />
        <div className="w-14 h-14 sm:w-16 sm:h-16 flex items-center justify-center">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-300/40 shadow-[0_0_10px_rgba(34,211,238,0.6)]" />
        </div>
        <PadArrow d="right" onDir={onDir} />
        <div />
        <PadArrow d="down" onDir={onDir} />
        <div />
      </div>
    </div>
  );
}
